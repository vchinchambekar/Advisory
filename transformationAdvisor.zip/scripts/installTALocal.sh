#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

set -e 
trap 'echo >&2 "Issue occurred with pulling Transformation Advisor Docker Images. Please check you can access IBMCOM."; ' ERR


./findHost.sh
sleep 2 
./findPort.sh
sleep 2 

#while :;do echo -n .;sleep 1;done &
#trap "kill $!" EXIT  2>/dev/null #Die with parent if we die prematurely
#disown
docker-compose pull > ../logs/PullingcouchDB_`date +"%Y%m%d_%H%M%S"`.log
docker-compose up -d > ../logs/InstallingTA_`date +"%Y%m%d_%H%M%S"`.log
#echo "" # or any other command here
#kill $! && trap " " EXIT 2>/dev/null


echo -n "Configuring Transformation Advisor.."
while :;do echo -n .;sleep 1;done &
trap "kill $!" EXIT  2>/dev/null #Die with parent if we die prematurely
disown
sleep 45 
echo "" # or any other command here
kill $! && trap " " EXIT 2>/dev/null


./copy_back_files.sh

#if uname -s | grep 'Darwin' > /dev/null ;
#    then
#    hostname=`hostname -f`
#    host_to_find=$(ifconfig | grep "inet " | grep -Fv $127.0.0.1 | awk '{print $2}')
#    host_to_find_array=( $host_to_find)

#    ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
#    echo "Status"
#    echo "------------------------------------------------------------------------------------------------------"
#    echo     "Transformation Advisor is available for us at the following URL> http://${host_to_find_array[0]}:$ui_port"


#    else
#     ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
#     hostname=`hostname -f`
#     echo "Status"
#     echo "------------------------------------------------------------------------------------------------------"
#     echo     "Transformation Advisor is available for us at the following URL> http://${hostname}:$ui_port"
#    fi

 if uname -s | grep 'Darwin' > /dev/null ;
                   then

                   ## if word address is returned instead of IP

                   host_to_find=$(ifconfig | grep "inet " | grep -E -o "([0-9]{1,3}[\.]){3}[0-9]{1,3}" | grep -Fv $127 | grep -Fv $172 | grep -Fv $255 | grep -Fv 0.0.0.0)
                   host_to_find_array=( $host_to_find)

                   #sort array
                   host_to_find_array=( $(printf "%s\n" ${host_to_find_array[@]} | sort -r ) )

                   ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
                   echo "Status"
                   echo "------------------------------------------------------------------------------------------------------"
                   echo     "Transformation Advisor is available for us at the following URL> http://${host_to_find_array[0]}:$ui_port"



                else
                        ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
                        hostname=`hostname -f`
                        echo "Status"
                        echo "------------------------------------------------------------------------------------------------------"
                        echo     "Transformation Advisor is available for us at the following URL> http://${hostname}:$ui_port"
                fi



