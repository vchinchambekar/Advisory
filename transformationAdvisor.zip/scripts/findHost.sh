<< --License--

Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2017

--License--

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

host=`hostname -f` 


if uname -s | grep 'Darwin' > /dev/null ;
        then
      
        ## if word address is returned instead of IP

        host_to_find=$(ifconfig | grep "inet " | grep -E -o "([0-9]{1,3}[\.]){3}[0-9]{1,3}" | grep -Fv $127 | grep -Fv $172 | grep -Fv $255 | grep -Fv 0.0.0.0)
        host_to_find_array=( $host_to_find)

        #sort array
        host_to_find_array=( $(printf "%s\n" ${host_to_find_array[@]} | sort -r ) )

        sed -i '' -e 's/<host>/'${host_to_find_array[0]}'/g' ./.env
        sed -i '' -e 's/<host>/'${host_to_find_array[0]}'/g' ./.env
        sed -i '' -e 's/hostname/'${host_to_find_array[0]}'/g' ./.env

else
	
	sed -i 's/<host>/'${host}'/g' ./.env
    	sed -i 's/<host>/'${host}'/g' ./.env
        sed -i 's/hostname/'${host}'/g' ./.env
	
fi
