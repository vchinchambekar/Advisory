#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"


./findHost.sh
sleep 1
./findPort.sh
sleep 1

docker-compose up -d > ../logs/InstallingTA_`date +"%Y%m%d_%H%M%S"`.log

echo -n "Configuring Transformation Advisor.."
while :;do echo -n .;sleep 1;done &
trap "kill $!" EXIT  2>/dev/null #Die with parent if we die prematurely
disown
sleep 45 
echo "" # or any other command here
kill $! && trap " " EXIT 2>/dev/null


 if uname -s | grep 'Darwin' > /dev/null ;
   then
       hostname=`hostname -f`
        host_to_find=$(ifconfig | grep "inet " | grep -Fv $127.0.0.1 | awk '{print $2}')
        host_to_find_array=( $host_to_find)

       ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
       echo "Status"
       echo "------------------------------------------------------------------------------------------------------"
       echo     "Transformation Advisor is available for us at the following URL> http://${host_to_find_array[0]}:$ui_port"


 else
       ui_port=$(docker ps | grep 3000  | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
       hostname=`hostname -f`
       echo "Status"
       echo "------------------------------------------------------------------------------------------------------"
       echo     "Transformation Advisor is available for us at the following URL> http://${hostname}:$ui_port"
fi


./copy_back_files.sh
